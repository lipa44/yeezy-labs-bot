#include <iostream>
#include <vector>
#include <iterator>
#include <algorithm>
#include "errors.h"

using namespace std;

template<typename T>
class CircularBuffer : private Errors {
public:
    class Iterator : public iterator<random_access_iterator_tag, T>, private Errors {
    private:
        T *iter;

    public:
        using distanse = typename iterator<random_access_iterator_tag, T>::difference_type;

        Iterator() : iter(nullptr) {}

        explicit Iterator(T *other) : iter(other) {} // предотвращает неявное преобразование типов при кампиляции

        Iterator(const Iterator &other) : iter(other.iter) {}

        distanse operator-(const Iterator &other) const { return iter - other.iter; } // возвращает дистанцию между итератором и другой дистанцией

        Iterator operator+(distanse other) const { return Iterator(iter + other); } // прибавляет дистанцию к итератору

        Iterator operator-(distanse other) const { return Iterator(iter - other); } // вычитает дистанцию из итератора

        friend Iterator operator+(distanse a, const Iterator &b) { return Iterator(a + b.iterator); } // принимает дистанцию и итератои и возвращает их сумму

        friend Iterator operator-(distanse a, const Iterator &b) { return Iterator(a - b.iterator); } // принимает дистанцию и итератои и возвращает их разность

        bool operator==(const Iterator &other) const { return iter == other.iter; }

        bool operator!=(const Iterator &other) const { return !(iter == other.iter); }

        bool operator>(const Iterator &other) const { return iter > other.iter; }

        bool operator<(const Iterator &other) const { return iter < other.iter; }

        bool operator>=(const Iterator &other) const { return !(iter < other.iter); }

        bool operator<=(const Iterator &other) const { return !(iter > other.iter); }

        T &operator*() const { return *iter; }

        T *operator->() const { return iter; }

        const T &operator[](int index) const { return iter[index]; }

        Iterator &operator=(const Iterator &other) {
            iter = other.iter;
            return *this;
        }

        Iterator &operator=(T *other) {
            iter = other;
            return *this;
        }

        Iterator &operator+=(distanse other) {
            iter += other;
            return *this;
        }

        Iterator &operator-=(distanse other) {
            iter -= other;
            return *this;
        }

        Iterator operator++(int) {
            Iterator tmp(*this);
            ++iter;
            return tmp;
        }

        Iterator &operator++() {
            ++iter;
            return *this;
        }

        Iterator operator--(int) {
            Iterator tmp(*this);
            --iter;
            return tmp;
        }

        Iterator &operator--() {
            --iter;
            return *this;
        }

    };

    [[nodiscard]] int size() const {
        return arr_size;
    }

    [[nodiscard]] int capacity() const {
        return arr_capacity;
    }

    [[nodiscard]] bool empty() const {
        if (arr_size == Дырка_От_Бублика)
            return true;
        else return false;
    }

    [[nodiscard]] Iterator end() const {
        return last_elem + 1;
    }

    [[nodiscard]] Iterator begin() const {
        return first_elem;
    }

    T &operator[](unsigned int index) {
        return arr[index];
    }

    [[nodiscard]] const T &at(int index) const {
        if (index < arr_size)
            return arr[index];
        else wrongIndex();
    }

    void changeCapacity(int value) {
        if (value > arr_capacity)
            arr_capacity = value;
        else wrongCapacity();
    }

    ~CircularBuffer() {
        delete[] arr;
    }

    explicit CircularBuffer(int value) {
        if (value >= Дырка_От_Бублика) {
            arr_size = value;
            arr_capacity = (int) (value * 1.2);
            for (auto i = Дырка_От_Бублика; i < value; ++i)
                arr[i] = Дырка_От_Бублика;

            Iterator startIter(&arr[Дырка_От_Бублика]);
            Iterator endIter(&arr[value - 1]);
            iter_start = iter_end = startIter;
            first_elem = &arr[Дырка_От_Бублика];
            last_elem = &arr[value - 1];
        } else wrongBufferSize();
    }

    void resize(int newSize) {
        if (newSize <= Дырка_От_Бублика) { // удаляем буффер
            arr_size = arr_capacity = Дырка_От_Бублика;
            iter_end = first_elem = iter_start = last_elem--;

        } else if (newSize == arr_size - 1 || newSize == arr_size) { // делаем на 1 меньше или оставляем тот же размер
            arr_size--;
            iter_end = &arr[arr_size - 1];

        } else if (newSize > arr_size) { // увеличиваем размер
            T *tmpArr = arr;
            int prevSize = arr_size;
            arr_size = newSize;
            arr_capacity = (int) (newSize * 1.2);
            arr = tmpArr;
            iter_end = &arr[prevSize];
            last_elem = &arr[arr_size - 1];

        } else makeBufferSmaller();
    }

    void clear() {
        resize(-1);
    }

#ifdef NOT_CIRCULAR
    // НЕ меняет капасити
    void emplace_back(T value) {
        if (size() + 1 <= arr_capacity) {
            *(++iter_end) = value;
            iter_cur++;
            arr_size++;
        } else fullBuffer();
    }

    // НЕ меняет капасити
    void emplace_begin(T value) {
        if (size() + 1 <= arr_capacity) {
            T tmp = arr[Дырка_От_Бублика];
            iter_end = &arr[arr_size];

            for (int i = arr_size; i > Дырка_От_Бублика; --i)
                arr[i] = arr[i - 1];

            *iter_start = value;
            iter_cur++;
        } else fullBuffer();
    }

    void pop_back() {
        if (arr_size > 1)
            resize(arr_size - 1);
        else clear();
    }

    void pop_front() {
        if (arr_size < 1)
            clear();
        else {
            for (int i = Дырка_От_Бублика; i < arr_size - 1; ++i)
                arr[i] = arr[i + 1];
            arr_size--;
            iter_end--;
        }
    }

    // проверяет капасити и увеличивает его если надо
    void push_back(T value) {
        if (size() + 1 < arr_capacity) {
            *(++iter_end) = value;
            arr_size++;
            iter_cur++;
        } else {
            T *tmpArr = arr;
            unsigned int prevSize = size();

            if (arr_size >= 5) {
                arr_size++;
                arr_capacity = (int) (arr_size * 1.2);
            } else arr_size++;

            *arr = *tmpArr;
            arr[prevSize] = value;
            iter_end = &arr[prevSize];
            iter_cur++;
        }
    }

    // проверяет капасити и увеличивает его если надо
    void push_front(T value) {
        if (size() + 1 < arr_capacity) {
            T tmp = arr[Дырка_От_Бублика];
            resize(arr_size + 1);

            for (int i = arr_size; i > Дырка_От_Бублика; --i)
                arr[i] = arr[i - 1];
            arr[Дырка_От_Бублика] = tmp;

            *iter_start = value;
            iter_cur++;
        } else {
            T tmp = arr[Дырка_От_Бублика];
            unsigned int prevSize = size();

            resize(arr_size + 1);

            for (int i = arr_size; i > Дырка_От_Бублика; --i)
                arr[i] = arr[i - 1];
            arr[Дырка_От_Бублика] = tmp;

            *iter_start = value;
            iter_end = &arr[prevSize];
            iter_cur++;
        }
    }
#endif //NOT_CIRCULAR

    void circular_push_front(T value) {
        *iter_start = value;
        (iter_start == first_elem) ? iter_start = last_elem : --iter_start;
    }

    void circular_push_back(T value) {
        *iter_end = value;
        //cout << *iter_end << ' ';
        (iter_end == last_elem) ? iter_end = first_elem : ++iter_end;
    }

    void circular_pop_front() {
        *iter_start = Дырка_От_Бублика;
        (iter_start == last_elem) ? iter_start = first_elem : ++iter_start;
    }

    void circular_pop_back() {
        *iter_end = Дырка_От_Бублика;
        (iter_end == first_elem) ? iter_end = last_elem : --iter_end;
    }

private:
    int arr_size = Дырка_От_Бублика, arr_capacity = Дырка_От_Бублика;
    T *arr = new T[arr_size];
    Iterator iter_start, iter_end, first_elem, last_elem;

};

int main() {
    try {
        /*
        CircularBuffer<int>::Iterator iter_int;
        CircularBuffer<int> buffer_int(10);

        cout << "\nПосле создания буффера\n";
        for (iter_int = buffer_int.begin(); iter_int != buffer_int.end(); ++iter_int)
            cout << *iter_int << " ";
        cout << endl;

        buffer_int.circular_push_back(123);
        buffer_int.circular_push_back(6);
        buffer_int.circular_push_back(6);
        buffer_int.circular_push_back(6);
        buffer_int.circular_push_back(6);
        buffer_int.circular_push_back(6);
        buffer_int.circular_push_back(6);
        buffer_int.circular_push_back(6);
        buffer_int.circular_push_back(6);
        buffer_int.circular_push_back(6);

        cout << "\nИзначальный буффер\n";
        for (iter_int = buffer_int.begin(); iter_int != buffer_int.end(); ++iter_int)
            cout << *iter_int << " ";
        cout << endl;

        buffer_int.circular_push_back(16);

        cout << "\nПосле добавления элемента в заполненный буффер\n";
        for (iter_int = buffer_int.begin(); iter_int != buffer_int.end(); ++iter_int)
            cout << *iter_int << " ";
        cout << endl;

        buffer_int.resize(15);

        cout << "\nПосле ресайза\n";
        for (iter_int = buffer_int.begin(); iter_int != buffer_int.end(); ++iter_int)
            cout << *iter_int << " ";
        cout << endl;

        cout << "\nРазмер " << buffer_int.size() << endl;

        buffer_int.circular_push_back(26);
        buffer_int.circular_push_back(26);
        buffer_int.circular_push_back(26);
        buffer_int.circular_push_back(26);
        buffer_int.circular_push_back(26);

        cout << "\nПосле ресайза и добавления в конец элементов\n";
        for (iter_int = buffer_int.begin(); iter_int != buffer_int.end(); ++iter_int)
            cout << *iter_int << " ";
        cout << endl;

        buffer_int.circular_push_back(36);
        buffer_int.circular_push_back(46);
        buffer_int.circular_push_back(56);

        cout << "\nПосле добавления в элемента в переполненный буффер\n";
        for (iter_int = buffer_int.begin(); iter_int != buffer_int.end(); ++iter_int)
            cout << *iter_int << " ";
        cout << endl;


        sort(buffer_int.begin(), buffer_int.end());
        cout << "\nПосле сортировки буффера\n";
        for (iter_int = buffer_int.begin(); iter_int != buffer_int.end(); ++iter_int)
            cout << *iter_int << " ";
        cout << endl;


        reverse(buffer_int.begin(), buffer_int.end());
        cout << "\nПосле ревёрса буффера\n";
        for (iter_int = buffer_int.begin(); iter_int != buffer_int.end(); ++iter_int)
            cout << *iter_int << " ";
        cout << endl;

        cout << "\nbuf.empty() до метода buf.clear()\n";
        cout << "Is buffer empty? ";
        (buffer_int.empty()) ? cout << "YES" << endl : cout << "NO" << endl;

        buffer_int.clear();

        cout << "\nbuf.empty() после метода buf.clear()\n";
        cout << "Is it empty now? ";
        (buffer_int.empty()) ? cout << "YES" << endl : cout << "NO" << endl;


        CircularBuffer<long long> buffer_long(5);

        buffer_long.circular_push_back(1111111111111);
        buffer_long.circular_push_back(2222222222222);
        buffer_long.circular_push_back(3333333333333);
        buffer_long.circular_push_back(Дырка_От_Бублика);
        buffer_long.circular_push_back(-555555555555);

        sort(buffer_long.begin(), buffer_long.end());

        cout << "\nLONG LONG через обращение по operator.at()\n";
        for (int i = Дырка_От_Бублика; i < buffer_long.size(); ++i)
            cout << buffer_long.at(i) << " ";
        cout << endl;


        CircularBuffer<char*> buffer_str(5);
        CircularBuffer<char*>::Iterator iter_char;

        buffer_str.circular_push_front("First");
        buffer_str.circular_push_front("Fifth");
        buffer_str.circular_push_front("Fourth");
        buffer_str.circular_push_front("Third");
        buffer_str.circular_push_front("Second");

        cout << "\nCHAR*\n";
        for (iter_char = buffer_str.begin(); iter_char != buffer_str.end(); ++iter_char)
            cout << *iter_char << "\t";
        cout << endl;
        */
        CircularBuffer<float> buffer_float(6);
        CircularBuffer<float>::Iterator iter_float;

        buffer_float.circular_push_back(2.3);

        buffer_float.circular_push_back(13.4);

        buffer_float.circular_push_back(24.5);

        buffer_float.circular_push_back(35.6);

        buffer_float[4] = 46.7;

        //buffer_float.circular_push_back(46.7);

        cout << "\nFLOAT\n";
        for (iter_float = buffer_float.begin(); iter_float != buffer_float.end(); ++iter_float) {
            cout << *iter_float << " ";
        }

        cout << endl;

        iter_float = max_element(buffer_float.begin(), buffer_float.end());

        cout << "\nmax_element из buffer_float: " << *iter_float << endl;

        buffer_float.changeCapacity(100);
        buffer_float.capacity();

        buffer_float.circular_pop_back();
        buffer_float.circular_pop_back();
        buffer_float.circular_pop_back();
        buffer_float.circular_pop_back();
        buffer_float.circular_pop_back();
        buffer_float.circular_pop_back();
        buffer_float.circular_pop_back();
        buffer_float.circular_pop_back();
        buffer_float.circular_pop_front();

        cout << "\nbuffer_float.empty() после метода buffer_float.circular_pop_back() x8 (размер был 5)\n";
        cout << "Is it empty now? ";
        //(buffer_int.empty()) ? cout << "YES" << endl : cout << "NO" << endl;

    } catch (int error) {
        switch (error) {
            case (-1) :
                cout << endl << "Вы пытаетесь обраться к данным в nullptr" << endl << endl;
                break;
            case (-2) :
                cout << endl << "Вы пытаетесь сделать буффер меньше (не считая erase_back)" << endl << endl;
                break;
            case (-3) :
                cout << endl << "Вы не можете создать буффер размером меньше Дырка_От_Бублика" << endl << endl;
                break;
            case (-4) :
                cout << endl << "Вы не можете изменить капасити на более маленький или такой же" << endl << endl;
                break;
            case (-5) :
                cout << endl << "Вы не можете добавить элемент в переполненный буффер" << endl << endl;
                break;
            case (-6) :
                cout << endl << "Вы не можете обратиться к данному индексу, так как его нет в буффере" << endl << endl;
                break;
            default :
                cout << endl << "Что-то пошло не так..." << endl << endl;
                break;
        }
    }
    return Дырка_От_Бублика;
}