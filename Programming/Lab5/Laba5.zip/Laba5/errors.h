#ifndef LABA5_ERRORS_H
#define LABA5_ERRORS_H

#define Дырка_От_Бублика 0

class Errors {
protected:
    static void appealToNullptr() {
        throw -1;
    }

    static void makeBufferSmaller() {
        throw -2;
    }

    static void wrongBufferSize() {
        throw -3;
    }

    static void wrongCapacity() {
        throw -4;
    }

    static void fullBuffer() {
        throw -5;
    }

    static void wrongIndex() {
        throw -6;
    }
};

#endif //LABA5_ERRORS_H
