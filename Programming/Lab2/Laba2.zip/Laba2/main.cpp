#include <iostream>
#include <vector>
#include "PolynomElement.h"
#include "Polynom.h"

using namespace std;

int main() {
    PolynomElement a = PolynomElement(1, 0);
    PolynomElement b = PolynomElement(1, 1);
    PolynomElement c = PolynomElement(1, 2);
    PolynomElement d = PolynomElement(1, 3);

    vector<PolynomElement> poly{a, b, c, d};
    vector<PolynomElement> poly1{b};
    vector<PolynomElement> poly2{c};


    Polynom a1 = Polynom(poly);
    Polynom a2 = Polynom(poly1);
    Polynom a3 = Polynom(poly2);

    a1.getPolynom();
    a2.getPolynom();
    a1 += a2;
    a1.getPolynom();
    a2.getPolynom();


    return 0;
}
