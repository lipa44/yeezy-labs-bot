#ifndef LABA2_POLYNOMELEMENT_H
#define LABA2_POLYNOMELEMENT_H

using namespace std;

class PolynomElement {
private:
    int factor = 0, power = 0;
    string sign;
public:

    PolynomElement() = default;

    PolynomElement(int fact, int pow) {
        this->factor=fact;
        this->power=pow;
    }

    void setFactor(int fact) {
        factor = fact;
    }

    void setPower(int pow) {
        power = pow;
    }

    void setSign(string str) {
        this->sign = move(str);
    }

    int getFactor() const {
        return factor;
    }

    int getPower() const {
        return power;
    }

    string getSign() const {
        return sign;
    }

    void setElement(int fact, int pow) {
        power = pow;
        factor = fact;
    }

    void getElement() const {
        if (power > 0) {
            if (factor != 0) {
                if (power == 1 && abs(factor) == 1) {
                    cout << sign << "x";
                } else if (power == 1 && abs(factor) != 1) {
                    cout << sign << abs(factor) << "x";
                } else if (power != 1 && abs(factor) == 1) {
                    cout << sign << "x^" << power;
                } else if (power != 1 && abs(factor) != 1) {
                    cout << sign << abs(factor) << "x^" << power;
                }
            }

        } else if (power < 0) {
            if (factor != 0) {
                if (power == -1 && abs(factor) == -1) {
                    cout << sign << abs(factor) << "/" << "x";
                } else if (power == -1 && abs(factor) != -1) {
                    cout << sign << abs(factor) << "/" << "x";
                } else if (power != -1 && abs(factor) == -1) {
                    cout << sign << abs(factor) << "/" << "x^" << abs(power);
                } else if (power != -1 && abs(factor) != -1) {
                    cout << sign << abs(factor) << "/" << "x^" << abs(power);
                }
            }
        } else if (power == 0 && abs(factor) != 0) {
            cout << sign << abs(factor);
        } else cout << 0 << endl;

    }

    ~PolynomElement() = default;
};

#endif //LABA2_POLYNOMELEMENT_H
