#ifndef LABA2_CALCULATIONS_H
#define LABA2_CALCULATIONS_H

void sumEqualPowers(vector<PolynomElement> &a) {
    if (!a.empty())
        for (int i = 0; i < a.size(); i++)
            for (int j = (i + 1); j < a.size(); j++)
                if (a[i].getPower() == a[j].getPower()) {
                    a[i].setFactor(a[i].getFactor() + a[j].getFactor());
                    a.erase(a.begin() + j);
                    j--;
                }
}

void sumConstants(vector<PolynomElement> &a) {
    if (!a.empty()) {
        PolynomElement constant;
        for (int j = 0; j < a.size(); j++) {
            if (a[j].getFactor() < 0) {
                a[j].setSign(" - ");
            } else if (a[j].getFactor() > 0)
                a[j].setSign(" + ");

            if (a[j].getPower() == 0) {
                constant.setFactor(constant.getFactor() + a[j].getFactor());
                a.erase(a.begin() + j);
                j--;
            }
        }

        if (constant.getFactor() < 0) {
            constant.setSign(" - ");
            a.push_back(constant);
        } else if (constant.getFactor() > 0) {
            constant.setSign(" + ");
            a.push_back(constant);
        }
    }
}

void sortByPowers(vector<PolynomElement> &a) {
    int size = a.size();
    if (size > 2) {
        for (int i = 0; i < a.size() - 1; i++) {
            for (int j = 1; j < a.size(); j++)
                if (a[j - 1].getPower() < a[j].getPower())
                    swap(a[j - 1], a[j]);
        }
    } else if (size == 2)
        if (a[0].getPower() < a[1].getPower())
            swap(a[0], a[1]);
}

void firstElementSign(vector<PolynomElement> &a) {
    if (!a.empty())
        if (a[0].getFactor() > 0) {
            a[0].setSign("");
        } else a[0].setSign("- ");
}

void invertFactors(vector<PolynomElement> &a) {
    int factor;
    for (auto &elem : a) {
        factor = -1 * elem.getFactor();
        elem.setFactor(factor);
    }
}

void createVector(const vector<PolynomElement> &a, const vector<PolynomElement> &b, vector<PolynomElement> &c) {
    c = a;
    if (!b.empty())
        for (auto &elem : b)
            c.emplace_back(elem);
}

void polygonMultipl(vector<PolynomElement> &a, vector<PolynomElement> &b) {
    vector<PolynomElement> mult;
    for (auto &elemA : a)
        for (auto &elemB : b)
            mult.emplace_back(elemA.getFactor()*elemB.getFactor(), elemA.getPower() + elemB.getPower());

    a = mult;
}

void polygonDiv(vector<PolynomElement> &a, vector<PolynomElement> &b) {

    vector<PolynomElement> div;
    int divCoef = 0, maxPow = 0;
    for (int i = 0; i < b.size(); i++) {
        if (b[i].getPower() == 0)
            divCoef = -1 * b[i].getFactor();
        if (b[i].getPower() > maxPow)
            maxPow = a[i].getPower();
    }

    if (divCoef != 0) {
        div.emplace_back(a[0].getFactor(), a[0].getPower() - 1);

        int coef = a[0].getFactor();
        for (int i = 1; i < a.size(); i++) {
            coef = coef * divCoef + a[i].getFactor();
            div.emplace_back(coef, a[i].getPower() - 1);
        }

        div[a.size() - 1].setPower(-1 * b[0].getPower());
        div.emplace_back(div[a.size() - 1].getFactor() / b[b.size() - 1].getFactor(), 0);

        a = div;
    } else {
        if (b[0].getPower() != 0)
            for (auto &elem : a) {
                elem.setFactor(elem.getFactor() / b[0].getFactor());
                elem.setPower(elem.getPower() - b[0].getPower());
            }
        else {
            cout << endl << "Sorry, data for div is invalid" << endl;
            a.clear();
        }
    }
}

#endif //LABA2_CALCULATIONS_H
