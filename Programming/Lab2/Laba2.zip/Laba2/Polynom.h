#ifndef LABA2_POLYNOM_H
#define LABA2_POLYNOM_H

#include "PolynomElement.h"
#include "Calculations.h"
#include <vector>

class Polynom {
private:
    vector<PolynomElement> PolynomVect;
public:

    explicit Polynom(vector<PolynomElement> &a) {
        this->setPolynom(a);
    }

    Polynom(const Polynom &a) {
        this->PolynomVect.resize(0);
        for (auto const &elem : a.PolynomVect)
            this->PolynomVect.emplace_back(elem);
    }

    void addElement(int factor, int power) {
        PolynomElement a;
        a.setElement(factor, power);
        PolynomVect.push_back(a);
        this->setPolynom(this->PolynomVect);
    }

    void setPolynom(vector<PolynomElement> &a) {
        PolynomVect = a;

        //суммирование множителей элементов с одинаковой степенью
        sumEqualPowers(this->PolynomVect);

        //нахождение констант в полиноме и их суммирование, а также добавление знаков элементам полинома
        sumConstants(this->PolynomVect);

        //сортировка по убыванию степеней
        sortByPowers(this->PolynomVect);

        //удаление знака у первого элемента
        firstElementSign(this->PolynomVect);

    }

    void getPolynom() {
        this->setPolynom(this->PolynomVect);

        if (!PolynomVect.empty()) {
            cout << endl << "Here is our polynom:" << endl;
            for (auto  &elem : PolynomVect)
                elem.getElement();
            cout << endl;
        } else cout << endl << "Sorry, polynom doesn't contain any elements" << endl;
    }

    Polynom() = default;

    ~Polynom() = default;


    // ОПЕРАТОРЫ


    // Оператор =
    Polynom &operator=(const Polynom &a) {
        PolynomVect.resize(a.PolynomVect.size());
        for (int i = 0; i < a.PolynomVect.size(); i++)
            PolynomVect[i] = a.PolynomVect[i];
        this->setPolynom(this->PolynomVect);

        return *this;
    }

    // Оператор ==
    bool operator==(const Polynom &a) {
        if (PolynomVect.size() == a.PolynomVect.size()) {
            for (int i = 0; i < a.PolynomVect.size(); i++) {
                if (PolynomVect[i].getFactor() != a.PolynomVect[i].getFactor() ||
                    PolynomVect[i].getPower() != a.PolynomVect[i].getPower())
                    return false;
            }
            return true;
        } else return false;
    }

    // Оператор !=
    bool operator!=(const Polynom &a) {
        return !(*this == a);
    }

    // Оператор +
    friend Polynom operator+(const Polynom &a, const Polynom &b) {
        if (a.PolynomVect.size() != -1 || b.PolynomVect.size() != -1) {
            vector<PolynomElement> sum;
            createVector(a.PolynomVect, b.PolynomVect, sum);
            return Polynom(sum);
        } else {
            cout << "Resulted polynom is empty" << endl;
            return Polynom();
        }
    }

    // Оператор унарный +
    friend Polynom operator+(const Polynom &a) {
        cout << "Hello world!" << endl;
        return a;
    }

    // Оператор унарный -
    friend Polynom operator-(Polynom &a) {
        invertFactors(a.PolynomVect);
        return a;
    }

    // Оператор -
    friend Polynom operator-(const Polynom &a, const Polynom &b) {
        if (a.PolynomVect.size() != -1 || b.PolynomVect.size() != -1) {
            vector<PolynomElement> dif;
            vector<PolynomElement> invertB = b.PolynomVect;
            invertFactors(invertB);
            createVector(a.PolynomVect, invertB, dif);
            return Polynom(dif);
        } else {
            cout << "Resulted polynom is empty" << endl;
            return Polynom();
        }
    }

    // Оператор ++
    friend Polynom &operator++(Polynom &d) {
        d.addElement(1, 0);
        return d;
    }

    // Оператор --
    friend Polynom &operator--(Polynom &d) {
        d.addElement(-1, 0);
        return d;
    }

    // Оператор +=
    Polynom &operator+=(Polynom &a) {
        *this = *this + a;
        return *this;
    }

    // Оператор -=
    Polynom &operator-=(Polynom &a) {
        *this = *this - a;
        return *this;
    }

    // Оператор *
    friend Polynom &operator*(Polynom &a, Polynom &b) {
        polygonMultipl(a.PolynomVect, b.PolynomVect);
        a.setPolynom(a.PolynomVect);
        return a;
    }

    // Оператор *=
    Polynom &operator*=(Polynom &a) {
        return *this * a;
    }

    // Оператор /
    friend Polynom &operator/(Polynom &a, Polynom &b) {
        polygonDiv(a.PolynomVect, b.PolynomVect);
        a.setPolynom(a.PolynomVect);
        return a;
    }

    // Оператор /=
    Polynom &operator/=(Polynom &a) {
        return *this / a;
    }

    // Оператор []
    PolynomElement &operator[](int index) {
        return this->PolynomVect[index];
    }

    // Оператор >>
    friend istream &operator>>(istream &cin_, Polynom &a) {
        cout << endl << "Polynom element requested" << endl;
        cout << "Print index you want to change ";
        int index;
        do {
            cin >> index;
            if (index >= a.PolynomVect.size()) {
                cout << "Sorry, it's invalid index. Try to enter different one" << endl;
            }
        } while (index >= a.PolynomVect.size());

        int factor, power;
        cout << "Print factor and power for element" << endl;
        if (cin_ >> factor && cin_ >> power) {
            a.PolynomVect[index] = PolynomElement(factor, power);
            cout << endl << "Successfully completed" << endl;
            a.setPolynom(a.PolynomVect);
        } else {
            cout << "Error, cannot find enough data for >>" << endl;
            exit(1);
        }
        return cin_;
    }

    // <<
    friend ostream &operator<<(ostream &cout_, Polynom &a) {
        cout << endl << "Polynom element requested" << endl;
        cout << "Print index you want to show ";
        int index;
        do {
            cin >> index;
            if (index >= a.PolynomVect.size()) {
                cout << "Sorry, it's invalid index. Try to enter different one" << endl;
            }
        } while (index >= a.PolynomVect.size());

        cout << endl << "Polynom's " << index << " index data: " << endl;
        cout_ << "Power: " << a.PolynomVect[index].getPower() << " Factor: " << a.PolynomVect[index].getPower() << endl;

        return cout_;
    }
};


#endif //LABA2_POLYNOM_H
