#ifndef LABA4_TRASH_H
#define LABA4_TRASH_H

#include <string>
#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

friend std::ostream &operator<<(std::ostream &cout_, Point &a) {
    cout_ << "Point: " << "x = " << a.getX() << " y = " << a.getY() << "\n";

    return cout_;
}

//функция для свапа данных ЛЮБОГО типа
template<typename T>
void swapFunc(T &a, T &b) {
    T temp = a;
    a = b;
    b = temp;
};

   //перечисляемый тип

   enum PCState {
       OFF = 10,
       ON,
       SLEEP = 12345
   };
   int state = PCState::ON;

/*
   //данные для свапа
   int a, b;
   swapFunc(a, b);


   //динамическое выделение памяти
   int *arr = new int[412500000];
   //int *arr1 = new int[100000000];
   delete[] arr;
   //delete[] arr1;


   //создание динамического массива произвольной длины
   int size = 10;
   int *array = new int[size];
   delete[] array;


   //тернарный оператор
   (a > 10) ? cout << "Джонни, ты победил" : cout << "Here we go again...";
   (a > 10) ? cout << "Johny, you won" : (a < 10) ? cout << "Here we go again..." : cout << "You fucked up...";


   class Human {
   private:
       float height;
       float weight;
       int age;
       string name;
       string surname;
       string studyPlace;
   public:
       void setHeight(float height_) {
           height = height_;
       }

       void getHeight() {
           cout << "Height is " << height << endl;
       }

       void setWeight(float weight_) {
           weight = weight_;
       }

       void getWeight() {
           cout << "Weight is " << weight << endl;
       }

       void setAge(float age_) {
           age = age_;
       }

       void getAge() {
           cout << "Age is " << age << endl;
       }

       void setName(string name_) {
           name = name_;
       }

       void getName() {
           cout << "Name is " << name << endl;
       }

       void setSurname(string surname_) {
           surname = surname_;
       }

       void getSurname() {
           cout << "Surname is " << surname << endl;
       }

       void setStudyPlace(string studyPlace_) {
           studyPlace = studyPlace_;
       }

       void getStudyPlace() {
           cout << "Study place is " << studyPlace << endl;
       }
   };

*/

#endif //LABA4_TRASH_H
