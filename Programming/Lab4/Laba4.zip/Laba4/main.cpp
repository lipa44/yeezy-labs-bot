#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

using std::vector;
using std::cout;

//#define SITUATIONAL

template<class T>
bool isNull(const T x) {
    return (x == 0);
}

template<class T>
bool isPointNull(const T x) {
    return (x.getX() == 0 && x.getY() == 0);
}

template<class T>
bool isPositive(const T x) {
    return (x > 0);
}

template<class T>
bool isSorted(const T x, const T y) {
    return (x > y);
}

template<class T>
bool isSymmetric(const T x, const T y) {
    return (x == y);
}

template<typename T>
class Point {
private:
    T x, y;
public:
    Point() {
#ifdef SITUATIONAL
        cout << "Point constructor " << sizeof(T) << " done" << "\n";
#endif //SITUATIONAL
    };

    Point(T x, T y) {
        this->x = x;
        this->y = y;
    };

    ~Point() {
#ifdef SITUATIONAL
        cout << "Point destructor " << sizeof(T) << " done" << "\n";
#endif //SITUATIONAL
    };

    [[nodiscard]] T getX() const {
        return this->x;
    }

    [[nodiscard]] T getY() const {
        return this->y;
    }
};

namespace MyAlgorithms {

// all_of
    template<typename T, typename Predicate>
    bool all_of(const T &begin, const T &end, const Predicate foo) {
        for (T i = begin; i < end; ++i)
            if (!foo(*i))
                return false;
        return true;
    }

// any_of
    template<typename T, typename Predicate>
    bool any_of(const T &begin, const T &end, const Predicate foo) {
        for (T i = begin; i < end; ++i)
            if (foo(*i))
                return true;
        return false;
    }

// none_of
    template<typename T, typename Predicate>
    bool none_of(const T &begin, const T &end, const Predicate foo) {
        return !(MyAlgorithms::any_of(begin, end, foo));
    }

// one_of
    template<typename T, typename Predicate>
    bool one_of(const T &begin, const T &end, const Predicate foo) {
        int count = 0;
        for (T i = begin; i < end; ++i)
            if (foo(*i))
                count++;

        if (count == 1) return true;
        else return false;
    }

// is_sorted
    template<typename T, typename Predicate>
    bool is_sorted(const T &begin, const T &end, const Predicate foo) {
        for (T i = begin; i < end - 1; ++i)
            if (!foo(*i, *(i + 1)))
                return false;
        return true;
    }

// is_partitioned
    template<typename T, typename Predicate>
    bool is_partitioned(const T &begin, const T &end, const Predicate foo) {
        T PBegin = begin, PEnd = end - 1;
        bool isCorrect = false;
        for (T i = begin; i < end; ++i) {
            if (!isCorrect) {
                if (foo(*PBegin++) != foo(*PBegin))
                    isCorrect = true;
            } else if (PBegin == PEnd) {
                break;
            } else if (foo(*PBegin++) != foo(*PBegin))
                return false;
        }
        return isCorrect;
    }

// find_not
    template<typename T, typename CT>
    CT find_not(const T &begin, const T &end, const CT member) {
        for (T i = begin; i < end; ++i)
            if (*i != member)
                return *i;
        return CT();
    }

// find_backward
    template<typename T, typename CT>
    CT find_backward(const T &begin, const T &end, const CT member) {
        for (T i = begin; i < end; ++i)
            if (*i == member)
                return *i;
        return CT();
    }

// is_palindrome
    template<typename T, typename Predicate>
    bool is_palindrome(const T &begin, const T &end, const Predicate foo) {
        bool isCorrect = false;
        T PBegin = begin, PEnd = end - 1;
        while (PBegin < PEnd) {
            if (foo(*PBegin++, *PEnd--)) {
                isCorrect = true;
            } else return false;
        }
        return isCorrect;
    }
}

int main() {
    Point a = Point<int>(0, 0);

    vector<int> dataInt = {10, 9, 8, 0, -2, -5, -8};
    vector<float> dataFloat = {10.10, 11, 10.10};
    vector<Point<int>> PVector = {Point<int>(3, 4), Point<int>(0, 0), Point<int>(3, 5), Point<int>(3, 3)};

    /*

    cout << "\n";

    cout << "all_of = " << (MyAlgorithms::all_of(PVector.cbegin(), PVector.cend(), isPointNull<Point<int>>) ? "True" : "False") << "\n";

    cout << "any_of = " << (MyAlgorithms::any_of(PVector.cbegin(), PVector.cend(), isPointNull<Point<int>>) ? "True" : "False") << "\n";

    cout << "none_of = " << (MyAlgorithms::none_of(dataFloat.cbegin(), dataFloat.cend(), isNull<float>) ? "True" : "False") << "\n";

    cout << "one_of = " << (MyAlgorithms::one_of(PVector.cbegin(), PVector.cend(), isPointNull<Point<int>>) ? "True" : "False") << "\n";

    cout << "is_sorted = " << (MyAlgorithms::is_sorted(dataInt.cbegin(), dataInt.cend(), isSorted<int>) ? "True" : "False") << "\n";

    cout << "is_partitioned = " << (MyAlgorithms::is_partitioned(dataInt.cbegin(), dataInt.cend(), isPositive<int>) ? "True" : "False") << "\n";

    cout << "find_not = " << MyAlgorithms::find_not(dataInt.cbegin(), dataInt.cend(), (int)10) << "\n";

    cout << "find_backward = " << MyAlgorithms::find_backward(dataFloat.crbegin(), dataFloat.crend(), (float)10.10) << "\n";

    cout << "is_palindrome = " << (MyAlgorithms::is_palindrome(dataFloat.cbegin(), dataFloat.cend(), isSymmetric<float>) ? "True" : "False") << "\n";
    */

    cout << count(dataInt.begin(), dataInt.end(), 10);

    return 0;
}
