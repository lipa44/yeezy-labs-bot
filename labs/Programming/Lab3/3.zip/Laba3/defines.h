#ifndef LABA3_DEFINES_H
#define LABA3_DEFINES_H

#include <iostream>
#include <utility>
#include <vector>
#include <algorithm>
#include <sstream>
#include <map>
#include <set>
#include <cmath>
#include "pugixml/pugixml.hpp"

#define CREATE_ELEM Transport_station(std::stoi(iter.child_value("number")), routes, iter.child_value("type_of_vehicle"), \
iter.child_value("object_type"), iter.child_value("name_stopping"), iter.child_value("the_official_name"), it_locations, coordinates)

#define to_radians (M_PI / 180)

#endif //LABA3_DEFINES_H
