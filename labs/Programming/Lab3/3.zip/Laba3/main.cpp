#include "defines.h"

using namespace std;

static map<string, float> tram_routes_size, bus_routes_size, trolleybus_routes_size; // пары "название маршрута" / длина маршрута
static map<string, int> tram_routes, bus_routes, trolleybus_routes; // пары "название маршрута" / количество упоминаний (по отдельным транспортам)
static map<string, int> locations; // пары "название локации" / количество упоминаний
static set<string> name_of_routes; // названия всех маршрутов

int max_tram_routes = 0, max_bus_routes = 0, max_trolleybus_routes = 0; // максимальное количество остановок
double dist_longest_tram_route = 0, dist_longest_bus_route = 0, dist_longest_trolleybus_route = 0; // счётчики длины этих самых маршрутов
int max_stops = 0; // наибольшее количество остановок

class Transport_station {
private:
    int number;
    string type_of_vehicle, object_type, name_stopping, the_official_name;
    vector<string> location, routes;
    pair<float, float> coordinates;

public:
    inline explicit Transport_station(int number, vector<string> routes, string type_of_vehicle, string object_type, string the_official_name,
                             string name_stopping, vector<string> location, pair<float, float> coord)
            : type_of_vehicle(move(type_of_vehicle)), number(number), routes(move(routes)),
              object_type(move(object_type)), the_official_name(move(the_official_name)),
              name_stopping(move(name_stopping)), location(move(location)), coordinates(move(coord)) {}

    inline string get_type_of_vehicle() const { return this->type_of_vehicle; }

    inline float get_coord_x() const { return this->coordinates.first; }

    inline float get_coord_y() const { return this->coordinates.second; }

    inline int routes_size() const { return this->routes.size(); }

    inline string operator[](const int index) const { return this->routes[index]; }
};

class Routes {
public:
    string route;
    vector<Transport_station> Tram, Bus, Trolleybus;
};

// структура для сортировки элементов в мапе (функтор)
struct comparator {
    template<typename T>
    bool operator()(const T &left, const T &right) const {
        if (left.second != right.second)
            return left.second > right.second;
        return left.first > right.first;
    }
};

void print_top(map<string, int> &old_map, int count) {
    set<pair<string, int>, comparator> sorted(old_map.begin(), old_map.end());
    int const_ = count;

    for (auto &it : sorted)
        (count-- > 0) ? cout << const_ - count << ") " << it.first << " ---> " << it.second << " шт.\n" : cout;
}

double find_dist(const Transport_station &a, const Transport_station &b) {
    double lat1 = a.get_coord_x() * to_radians;
    double long1 = a.get_coord_y() * to_radians;
    double lat2 = b.get_coord_x() * to_radians;
    double long2 = b.get_coord_y() * to_radians;

    double delta_long = long2 - long1;
    double delta_lat = lat2 - lat1;

    double dist = pow(sin(delta_lat / 2), 2) +
                  cos(lat1) * cos(lat2) *
                  pow(sin(delta_long / 2), 2);

    int earth_radius_km = 6371;

    dist = 2 * asin(sqrt(dist)) * earth_radius_km;

    return dist;
}

void parse_pair(const string &str1, string &str2, string &str3) {
    string separator = ",";

    auto start = 0;
    auto end = str1.find(separator);
    while (end != -1) {
        str2 = str1.substr(start, end - start);
        start = end + separator.length();
        end = str1.find(separator, start);
    }

    str3 = str1.substr(start, end);
}

inline void make_str_correct(string temp, string &current){
    temp += current;
    current = temp;
}

string make_location_correct(string &str) {
    vector<string> errors {"ул.", " ул.", " УЛ.", " ш.", " Ш.", " шоссе", " ШОССЕ", " пер.", " ПЕР.", " переулок",
                          " ПЕРЕУЛОК", " улица", "улица", " УЛИЦА", " бул", " БУЛ", " бульвар", " БУЛЬВАР", " пр",
                          " ПР", " проспект", " ПРОСПЕКТ", "пл. ", "площадь ", " площадь", " пл.", "пр. ", "проспект ",
                          "проспект", "ш. ", "шоссе ", "наб. ", "набережная ", "наб.", " наб", " дор", "дор. ",
                          " дорога", " набережная", " аллея", " мост"};

    for (auto const &elem: errors)
        if (str.find(elem) != -1) {
            unsigned long first = str.find(elem);
            unsigned long second = first + elem.size();
            str.erase(first, second);

            if (str[str.size() - 1] == ' ')
                while (str[str.size() - 1] == ' ')
                    str.erase(str.end() - 1);
            if (str[0] == ' ')
                while (str[0] == ' ')
                    str.erase(str.begin());

            if (elem == "ул." || elem == " ул." || elem == " УЛ." || elem == " улица" || elem == "улица" || elem == " УЛИЦА")
                make_str_correct("улица ", str);

            else if (elem == " ш." || elem == " Ш." || elem == " шоссе" || elem == " ШОССЕ" || elem == "ш. " || elem == "шоссе ")
                make_str_correct("шоссе ", str);

            else if (elem == " пер." || elem == " ПЕР." || elem == " переулок" || elem == " ПЕРЕУЛОК")
                make_str_correct("переулок ", str);

            else if (elem == " бул" || elem == " БУЛ" || elem == " бульвар" || elem == " БУЛЬВАР")
                make_str_correct("бульвар ", str);

            else if (elem == " пр" || elem == " ПР" || elem == " проспект" || elem == " ПРОСПЕКТ" || elem == "пр. " || elem == "проспект " || elem == "проспект")
                make_str_correct("проспект ", str);

            else if (elem == "пл. " || elem == "площадь " || elem == " площадь" || elem == " пл.")
                make_str_correct("площадь ", str);

            else if (elem == "наб. " || elem == "набережная " || elem == "наб." || elem == " набережная" || elem == " наб")
                make_str_correct("набережная ", str);

            else if (elem == " дор" || elem == " дорога" || elem == "дор. ")
                make_str_correct("дорога ", str);

            else if (elem == " аллея")
                make_str_correct("аллея ", str);

            else if (elem == " мост")
                make_str_correct("мост ", str);

            break;
        }

    return str;
}

void correct_repeated_locations() {
    map<string, int> temp = locations;
    map<string, int> new_locations;
    vector<string> names{"шоссе ", "улица ", "мост ", "дорога ", "набережная ", "переулок ", "площадь ", "проспект "};

    for (auto &elem : locations) {
        bool is_changed = false;
        string temp_str = elem.first;
        for (auto &name : names) {
            make_str_correct(name, temp_str);
            if (temp[temp_str] != 0) {
                new_locations[temp_str] = locations[elem.first] + locations[temp_str];
                is_changed = true;
                break;
            }
            temp_str = elem.first;
        }

        if (!is_changed)
            new_locations[elem.first] = locations[elem.first];
    }

    locations = new_locations;
}

void parse_file(vector<Transport_station> &el, map<string, Routes> &map_routes, set<string> &name_routes) {
    pugi::xml_document doc;
    doc.load_file("input.xml");
    pugi::xml_node data = doc.child("dataset");

    for (pugi::xml_node iter = data.child("transport_station"); iter; iter = iter.next_sibling("transport_station")) {

        //работа с координатами
        string str1, str2;
        parse_pair(iter.child_value("coordinates"), str1, str2);
        float first_coord = stof(str1), second_coord = stof(str2);
        pair<float, float> coordinates = make_pair(first_coord, second_coord);

        //работа с маршрутами
        str1 = str2 = "";
        string routes_str = iter.child_value("routes"), segment;
        vector<string> routes;

        stringstream temp_route_str(routes_str);
        if (count(routes_str.begin(), routes_str.end(), ',')) {
            while (getline(temp_route_str, segment, ','))
                routes.push_back(segment);
        } else
            while (getline(temp_route_str, segment, '.'))
                routes.push_back(segment);

        //работа с локацией
        str1 = str2 = "";
        string location_str = iter.child_value("location");
        vector<string> it_locations;

        stringstream temp_location_str(location_str);
        if (count(location_str.begin(), location_str.end(), ',') && !location_str.empty()) {
            while (getline(temp_location_str, segment, ',')) {
                if (segment[0] == ' ')
                    segment.erase(segment.begin());
                it_locations.push_back(make_location_correct(segment));
                locations[make_location_correct(segment)] += 1;
            }
        } else if (!location_str.empty()) {
            it_locations.push_back(make_location_correct(location_str));
            locations[make_location_correct(location_str)] += 1;
        }

        el.emplace_back(CREATE_ELEM);

        if (!strcmp(iter.child_value("type_of_vehicle"), "Трамвай"))
            for (auto const &elem : routes) {
                map_routes[elem].Tram.emplace_back(CREATE_ELEM);
                map_routes[elem].route = elem;
                name_routes.insert(elem);
            }

        else if (!strcmp(iter.child_value("type_of_vehicle"), "Автобус"))
            for (auto const &elem : routes) {
                map_routes[elem].Bus.emplace_back(CREATE_ELEM);
                map_routes[elem].route = elem;
                name_routes.insert(elem);
            }

        else if (!strcmp(iter.child_value("type_of_vehicle"), "Троллейбус"))
            for (auto const &elem : routes) {
                map_routes[elem].Trolleybus.emplace_back(CREATE_ELEM);
                map_routes[elem].route = elem;
                name_routes.insert(elem);
            }
    }

    correct_repeated_locations();
}

void set_routes(vector<Transport_station> &stations) {

    for (auto const &elem: stations) {
        if (elem.get_type_of_vehicle() == "Трамвай")
            for (int i = 0; i < elem.routes_size(); ++i)
                tram_routes[elem[i]] += 1;

        else if (elem.get_type_of_vehicle() == "Автобус")
            for (int i = 0; i < elem.routes_size(); ++i)
                bus_routes[elem[i]] += 1;

        else if (elem.get_type_of_vehicle() == "Троллейбус")
            for (int i = 0; i < elem.routes_size(); ++i)
                trolleybus_routes[elem[i]] += 1;
    }
}

void calculate_count_routes(string &biggest_tram_route, string &biggest_bus_route, string &biggest_trolleybus_route) {
    for (auto const &elem: tram_routes)
        if (elem.second > max_tram_routes) {
            max_tram_routes = elem.second;
            biggest_tram_route = elem.first;
        }

    for (auto const &elem: bus_routes)
        if (elem.second > max_bus_routes) {
            max_bus_routes = elem.second;
            biggest_bus_route = elem.first;
        }

    for (auto const &elem: trolleybus_routes)
        if (elem.second > max_trolleybus_routes) {
            max_trolleybus_routes = elem.second;
            biggest_trolleybus_route = elem.first;
        }

    cout << "\n";
    cout << "Наибольшее количество остановок у трамвая равно: " << max_tram_routes << " шт. Номер маршрута "
         << biggest_tram_route
         << "\n";
    cout << "Наибольшее количество остановок у автобуса равно: " << max_bus_routes << " шт. Номер маршрута "
         << biggest_bus_route
         << "\n";
    cout << "Наибольшее количество остановок у троллейбуса равно: " << max_trolleybus_routes << " шт. Номер маршрута "
         << biggest_trolleybus_route << "\n";
}

void set_distances(map<string, Routes> &routes) {
    for (auto const &name : name_of_routes) {
        if (routes[name].Tram.size() > 1)
            for (int i = 0; i < routes[name].Tram.size() - 1; ++i)
                tram_routes_size[routes[name].route] += find_dist(routes[name].Tram[i], routes[name].Tram[i + 1]);

        if (routes[name].Bus.size() > 1)
            for (int i = 0; i < routes[name].Bus.size() - 1; ++i)
                bus_routes_size[routes[name].route] += find_dist(routes[name].Bus[i], routes[name].Bus[i + 1]);

        if (routes[name].Trolleybus.size() > 1)
            for (int i = 0; i < routes[name].Trolleybus.size() - 1; ++i)
                trolleybus_routes_size[routes[name].route] += find_dist(routes[name].Trolleybus[i], routes[name].Trolleybus[i + 1]);
    }
}

void find_longest_route(string &longest_tram_route, string &longest_bus_route, string &longest_trolleybus_route) {
    for (auto const &elem: tram_routes_size)
        if (elem.second > dist_longest_tram_route) {
            dist_longest_tram_route = elem.second;
            longest_tram_route = elem.first;
        }

    for (auto const &elem: bus_routes_size)
        if (elem.second > dist_longest_bus_route) {
            dist_longest_bus_route = elem.second;
            longest_bus_route = elem.first;
        }

    for (auto const &elem: trolleybus_routes_size)
        if (elem.second > dist_longest_trolleybus_route) {
            dist_longest_trolleybus_route = elem.second;
            longest_trolleybus_route = elem.first;
        }

    cout << "\n";
    cout << "Наиболее длиный маршрут трамвая: " << longest_tram_route << "\n";
    cout << "Наиболее длиный маршрут автобуса: " << longest_bus_route << "\n";
    cout << "Наиболее длиный маршрут троллейбуса: " << longest_trolleybus_route << "\n";
}

void find_largest_street(string &largest_street) {
    for (auto const &elem: locations)
        if (elem.second > max_stops) {
            max_stops = elem.second;
            largest_street = elem.first;
        }

    cout << "\n" << "Наибольшее количество остановок на \"" << largest_street << "\" равно " << max_stops << " шт.\n";
}

int main() {
    vector<Transport_station> stations; // вектор со всеми станциями, в каждой из которых хранится вся информация о ней
    map<string, Routes> routes; // пары "название маршрута" / вектора транспортов с такими маршрутами

    parse_file(stations, routes, name_of_routes); // парсинг файла

    set_routes(stations); // записываем в контейнеры транспортов их маршруты

    string biggest_tram_route, biggest_bus_route, biggest_trolleybus_route; // названия маршрутов с наибольшим количеством остановок
    calculate_count_routes(biggest_tram_route, biggest_bus_route, biggest_trolleybus_route); // высчитываем количество маршрутов

    set_distances(routes); // устанавливаем длины маршрутов

    string longest_tram_route, longest_bus_route, longest_trolleybus_route; // названия самых длиных маршрутов
    find_longest_route(longest_tram_route, longest_bus_route, longest_trolleybus_route); // находим самый длинный маршрут

    string largest_street; // улица с наибольшим количеством остановок
    find_largest_street(largest_street); // находим улицу с наибольшим количеством остановок

    int n = 10;
    cout << "\nТоп " << n << " локаций по количеству остановок: \n";
    print_top(locations, n);

    return 0;
}