#include "classes/Point.h"
#include "classes/BrokenLine.h"
#include "classes/ChainedBrokenLine.h"
#include "classes/Figure.h"
#include "classes/Polygon.h"
#include "classes/Trapezoid.h"
#include "classes/Triangle.h"
#include "classes/RegularPolygon.h"

int main() {

    ChainedBrokenLine a;

    Figure *t[4];
    t[0] = new Triangle();
    t[1] = new Trapezoid();
    t[2] = new RegularPolygon();

    t[0]->setPolygon();

    for (int i = 0; i< 3; ++i)
        cout << (t[i])->square() << endl;

    return 0;
}
