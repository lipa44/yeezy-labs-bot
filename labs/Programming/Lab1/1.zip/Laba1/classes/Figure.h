#ifndef __FIGURE_H
#define __FIGURE_H

//#define COMMENTS

//абстрактный класс
class Figure {
protected:
    vector<Point> PolyVect;
public:
    //Конструктор по умолчанию
    Figure() {
#ifdef COMMENTS
        cout << endl << "Figure been successfully created" << endl;
#endif //COMMENTS
    };

    //виртуальные функции
    virtual float perimeter() = 0;

    virtual float square() = 0;

    virtual void getPolygon() = 0;

    virtual void setPolygon() = 0;

    virtual void getInfo() = 0;

    //Деструктор
    ~Figure() {
#ifdef COMMENTS
        cout << "Figure died" << endl;
#endif //COMMENTS
    }

};

#endif //__FIGURE_H
