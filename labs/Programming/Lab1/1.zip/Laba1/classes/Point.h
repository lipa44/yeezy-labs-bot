#ifndef __POINT_H
#define __POINT_H

#include <iostream>

//#define COMMENTS
//#define SITUATIONAL

using namespace std;

class Point {
private:
    float x, y;
public:
    //Конструктор по умолчанию
    Point() : x(0), y(0) {
#ifdef COMMENTS
        cout << "Point constructor successfully done" << endl;
#endif //COMMENTS
    }

    //Конструктор, присваивающий значения x и y
    Point(const float _x,const float _y) : x(_x), y(_y) {
#ifdef COMMENTS
        cout << "float point constructor successfully done" << endl;
#endif //COMMENTS
    }

    //Конструктор, присваивающий значения x и y
    Point(const int _x,const  int _y) : x(_x), y(_y) {
#ifdef COMMENTS
        cout << "int point constructor successfully done" << endl;
#endif //COMMENTS
    }

    //Конструктор копирования
    Point(const Point &t) {
        this->x = t.getX();
        this->y = t.getY();
#ifdef COMMENTS
        cout << endl << "Point has been successfully copied!" << endl;
#endif //COMMENTS
    }

    //Методы для работы с приватными данными (интерфейсы)
    [[maybe_unused]] void setX(const float _x) {
        this->x = _x;
    }

    [[maybe_unused]] void setY(const float _y) {
        this->y = _y;
    }

    [[nodiscard]] float getX() const {
        return this->x;
    }

    [[nodiscard]] float getY() const {
        return this->y;
    }

    [[maybe_unused]] void getInfo() const {
        cout << "________________________________________________\n";
        cout << "All info about it's point:" << endl << endl;
        cout << "y = " << this->getY() << "\tx = " << this->getX() << endl;
        cout << "Dist for point to zero: " << this->ToZero() << endl;
        cout << "________________________________________________\n";
    }

    //Оператор присванивания
    Point &operator=(const Point &t) {
        this->x = t.getX();
        this->y = t.getY();

#ifdef COMMENTS
        cout << "Operator =" << endl;
#endif //COMMENTS

        return *this;
    };

    //Расстояние от центра координат до точки
    [[nodiscard]] float ToZero() const {
        return sqrt(pow(x, 2) + pow(y, 2));
    }

    //Деструктор
    ~Point() {
#ifdef COMMENTS
        cout << "Point died" << endl;
#endif //COMMENTS
    }
};

#endif //__POINT_H
