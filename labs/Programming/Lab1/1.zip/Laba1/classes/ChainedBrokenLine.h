#ifndef __CHAINEDBROKENLINE_H
#define __CHAINEDBROKENLINE_H

//#define COMMENTS
//#define SITUATIONAL

class ChainedBrokenLine : public BrokenLine {
public:
    //Конструктор по умолчанию
    ChainedBrokenLine() {
#ifdef COMMENTS
        cout << "Chained broken line been successfully created" << endl;
#endif //COMMENTS
    }

    //Кнструктор через вектор точек
    [[maybe_unused]] explicit ChainedBrokenLine(const vector<Point> &m) {
        if (m.size() >= 3 && getSquare(m) != 0) {
            this->BLVect = m;
#ifdef COMMENTS
            cout << endl << "Congrats! Broken line (Chained broken line) has been successfully created!" << endl;
#endif //COMMENTS
        } else cout << "Sorry, it's not a chained broken line" << endl;
    }

    //Оператор присваивания
    ChainedBrokenLine &operator=(const ChainedBrokenLine &t) {
        this->BLVect.resize(0);
        for (auto const &elem : t.BLVect)
            this->BLVect.emplace_back(elem);
#ifdef COMMENTS
        cout << "Operator =" << endl;
#endif //COMMENTS

        return *this;
    }

    //Вычисления
    float length() override {
        return getPetimeter(this->BLVect);
    }

    //Деструктор
    ~ChainedBrokenLine() {
#ifdef COMMENTS
        cout << "Chained broken line died" << endl;
#endif
    }

};

#endif //__CHAINEDBROKENLINE_H
