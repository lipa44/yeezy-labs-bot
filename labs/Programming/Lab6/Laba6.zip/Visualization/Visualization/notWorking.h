#ifndef notWorking_h
#define notWorking_h

// works but makes Cube invalid
/*
void setRandomColors() {
    srand(time(0));
    vector<pair<string, int>> colors = {make_pair("W", 8), make_pair("R", 8), make_pair("G", 8), make_pair("B", 8), make_pair("Y", 8), make_pair("O", 8)};

    this->CreateRubikCube();

    // front
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j) {
            int index = rand() % 6;
            if (colors[index].second != 0 && !(i == 1 && j == 1))
                FrontPlane[i][j]->setFrontColor(colors[index].first),
                        colors[index].second--;
            else if (i == 1 && j == 1)
                continue;
            else
                j--;
        }

    // back
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j) {
            int index = rand() % 6;
            if (colors[index].second != 0 && !(i == 1 && j == 1))
                BackPlane[i][j]->setBackColor(colors[index].first),
                        colors[index].second--;
            else if (i == 1 && j == 1)
                continue;
            else
                j--;
        }

    // up
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j) {
            int index = rand() % 6;
            if (colors[index].second != 0 && !(i == 1 && j == 1))
                UpPlane[i][j]->setUpColor(colors[index].first),
                        colors[index].second--;
            else if (i == 1 && j == 1)
                continue;
            else
                j--;
        }

    // down
    for (int i = 0, ik = 2; i < 3; ++i, --ik)
        for (int j = 0; j < 3; ++j) {
            int index = rand() % 6;
            if (colors[index].second != 0 && !(i == 1 && j == 1))
                DownPlane[i][j]->setDownColor(colors[index].first),
                        colors[index].second--;
            else if (i == 1 && j == 1)
                continue;
            else
                j--;
        }

    // left
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j) {
            int index = rand() % 6;
            if (colors[index].second != 0 && !(i == 1 && j == 1))
                LeftPlane[i][j]->setLeftColor(colors[index].first),
                        colors[index].second--;
            else if (i == 1 && j == 1)
                continue;
            else
                j--;
        }

    // right
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j) {
            int index = rand() % 6;
            if (colors[index].second != 0 && !(i == 1 && j == 1))
                RightPlane[i][j]->setRightColor(colors[index].first),
                        colors[index].second--;
            else if (i == 1 && j == 1)
                continue;
            else
                j--;
        }
}
*/

#endif /* notWorking_h */